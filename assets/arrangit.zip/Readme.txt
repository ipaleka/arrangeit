ArrangeIt v0.91 for Win95/98/NT
Copyright (C) 1999, argusware
All Rights Reserved

Contents
1. Introduction
2. System requirements
3. Install/Uninstall
4. Getting started
5. History revision
6. Contact the author
7. Regards to

1. Introduction
***************

ArrangeIt is window manager utility that can reduce time spend on arranging windows on the desktop, improve the way you do that, speed up changing their dimensions and gives you additional views on the windows. After it has loaded, you will notice its icon in the tray. Just click on it with left mouse button to start arranging windows in new and improved ways! 'Tile Horizontally' and 'Tile Vertically' are methods that can help you only in specific situations, so take a look to this software.

2. System requirements
**********************

ArrangeIt would work on any system capable to run MS Windows 95. Only requirements is that you must have MS Visual Basic 5 runtime modules installed.

3. Install / Uninstall
**********************

There is two install packages available for ArrangeIt. The first with VB5 runtime modules (ArrIt-f.exe) and the other without them (ArrIt-s.exe). To install ArrangeIt simply run exe and follow the instructions. If you have some previous version of ArrangeIt installed, uninstall it before proceed. You can uninstall ArrangeIt from Control Panel - Add/Remove Programs.
If you are upgrading ArrangeIt, "Prepare to uninstall" from Options menu isn't necessary.
You don't need to uninstall ArrangeIt if you have installed install package without VB5 runtime modules and you don't have VB5 modules installed. Download the VB5 runtimes install package from ArrangeIt Home Page or from anywhere else and install it. ArrangeIt will work after that.

4. Getting started
******************

To start ArrangeIt click on its icon in Start/Programs menu. Options and Help you will get by clicking the icon in tray with right mouse button. See Help section for instructions of using ArrangeIt.

5. History revision
*******************

Version 0.91 (this version)
 - Hotkey added (combination of the keys that start windows arranging)

Version 0.90
 - The frame would act like a magnet in relation with windows on desktop if you were holding down the Space bar
 - Preview window while resizing frame by Enter key
 - Some bugs fixed

Version 0.80b
 - Function keys for displaying windows in standard dimensions added
 - Dimensions of the frame/window added in the frame
 - Shape and color of the frame changed to 3D look
  
Version 0.7
 - First distributed version

6. Contact the author
*********************

You can contact me 
 - by e-mail at ipaleka@orbicon.com
 - by ICQ - UIN 2276624

Everything about ArrangeIt you can see at
http://orbicon.com/arrangeit
- or -
http://members.xoom.com/argusware/arrangeit.htm

7. Regards to
*************

 - Zlatko Frigan (zlatko.frigan@zd.tel.hr), the greatest beta tester in Croatia
 - Dobrislav Klement (dklement@orbicon.com ; http://www.orbicon.com) for very useful suggestions and making ArrangeIt logo
 - BUG magazine (http://www.bug.hr) for the first presenting of ArrangeIt on a CD-ROM
