ArrangeIt v0.91 za Win95/98/NT
Copyright (C) 1999, argusware
Sva prava zadr�ana

Sadr�aj
1. Uvod
2. Sistemski zahtjevi
3. Instalacija/Deinstalacija
4. Kako po�eti
5. Razvoj programa
6. Kontaktiranje autora
7. Zahvale

1. Uvod
*******

ArrangeIt je utility koji vam mo�e skratiti vrijeme potrebno za postavljanje prozora na desktop i izmjenu njihovih dimenzija, te vam dati i neke nove poglede na prozore. Nakon pokretanja �ete primjetiti njegovu ikonu u tray-u. Kliknite je lijevom tipkom mi�a i zapo�nite postavljanje prozora na novi i pobolj�ani na�in. 'Tile Horizontally' and 'Tile Vertically' su metode za postavljanje prozora koje vam mogu pomo�i samo u specifi�nim situacijama, stoga pogledajte kako to radi ArrangeIt.

2. Sistemski zahtjevi
*********************

ArrangeIt �e se mo�i pokrenuti na svakom sistemu koji ima instalirane barem MS Windows 95. Jedino sto ArrangeIt zahtjeva su MS Visual Basic radne datoteke.

3. Install / Uninstall
**********************

Postoje dva instalacijska paketa. Prvi s VB5 radnim datotekama (ArrIt-f.exe) i drugi bez njih (ArrIt-s.exe). Za instalaciju pokrenite navedeni exe i slijedite instrukcije. Ako imate instaliranu neku od ranijih verzija, deinstalirajte ju.
Deinstalirati ArrangeIt mo�ete iz Control Panela - Add/Remove Programs.
Ako vr�ite nadogradnju ArrangeIt-a novom verzijom, ne morate pokrenuti "Priprema za deinstalaciju" iz sekcije Opcije programa.
Ako ste kojim slu�ajem instalirali verziju bez VB5 radnih datoteka, ne morate raditi deinstalaciju. Download-ajte VB5 instalaciju radnih datoteka s ArrangeIt WWW stranica (ili ju instalirajte s CD-ROM-a koji dolaze uz hrvatske informati�ke �asopise, tako�er mo�e i download bilo gdje s Interneta). ArrangeIt �e nakon te instalacije raditi.

4. Kako po�eti
**************

Za startanje ArrangeIt-a kliknite na ikonu u Start/Programs meniju. Opcije i Pomo� �ete dobiti klikom desne tipke mi�a na ikonu u tray-u. Daljnje instrukcije za rad �ete dobiti u sekciji Pomo�.

5. Razvoj programa
******************

Verzija 0.91 (ova verzija)
- Dodan je hotkey (kombinacija tipki koja zapo�inje postavljanje prozora)

Verzija 0.90
 - Kad dr�ite pritisnutu razmaknicu, okvir �e biti privu�en poput magneta na rubove
prozora na desktopu
 - Dok raste�ete okvir pritisnite tipku Enter da biste vidjeli kako bi prozor izgledao kad bi u tom trenutku zavr�ili postavljanje
 - Ispravke nekih bugova su u�injene

Version 0.80b
 - Dodane su funkcijske tipke za postavljanje prozora u standardne MS Windows dimenzije 
 - Dodana je opcija za prikaz dimenzija trenutnog okvira/prozora
 - Oblik i boja okvira su izmjenjeni u 3D izgled
  
Version 0.7
 - Prva objavljena verzija

6. Kontaktiranje autora
***********************

Mo�ete me dobiti preko 
 - e-mail-a: ipaleka@orbicon.com
 - ICQ-a: UIN 2276624

Sve oko ArrangeIt-a je dostupno na:
http://orbicon.com/arrangeit
- ili -
http://members.xoom.com/argusware/arrangeith.htm

7. Zahvale
**********

 - Zlatku Friganu (zlatko.frigan@zd.tel.hr), najve�em beta testeru u Hrvata :-)
 - Dobrislavu Klementu (dklement@orbicon.com ; http://www.orbicon.com) za vrlo korisne sugestije i izradu ArrangeIt logotipa
 - �asopisu BUG (http://www.bug.hr) za prvo objavljivanje ArrangeIt-a na CD-ROM-u
